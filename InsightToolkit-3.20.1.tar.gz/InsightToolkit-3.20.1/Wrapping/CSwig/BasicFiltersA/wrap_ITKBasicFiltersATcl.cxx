#define ITK_WRAP_PACKAGE "ITKBasicFiltersATcl"
#include "wrap_ITKBasicFiltersA.cxx"
