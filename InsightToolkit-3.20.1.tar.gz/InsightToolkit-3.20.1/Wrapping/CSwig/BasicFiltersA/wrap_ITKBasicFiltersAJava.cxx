#define ITK_WRAP_PACKAGE "ITKBasicFiltersAJava"
#include "wrap_ITKBasicFiltersA.cxx"
