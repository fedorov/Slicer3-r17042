#define ITK_WRAP_PACKAGE "ITKBasicFiltersAPython"
#include "wrap_ITKBasicFiltersA.cxx"
