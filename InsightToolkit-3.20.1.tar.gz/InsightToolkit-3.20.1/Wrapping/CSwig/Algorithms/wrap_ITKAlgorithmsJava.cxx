#define ITK_WRAP_PACKAGE "ITKAlgorithmsJava"
#include "wrap_ITKAlgorithms.cxx"
