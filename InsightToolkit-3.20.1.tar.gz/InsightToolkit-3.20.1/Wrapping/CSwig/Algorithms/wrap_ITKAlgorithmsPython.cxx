#define ITK_WRAP_PACKAGE "ITKAlgorithmsPython"
#include "wrap_ITKAlgorithms.cxx"
