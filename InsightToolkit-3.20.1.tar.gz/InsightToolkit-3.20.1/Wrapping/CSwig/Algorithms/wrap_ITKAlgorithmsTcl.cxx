#define ITK_WRAP_PACKAGE "ITKAlgorithmsTcl"
#include "wrap_ITKAlgorithms.cxx"
