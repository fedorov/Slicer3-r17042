#define ITK_WRAP_PACKAGE "ITKCommonBPython"
#define ITK_PYTHON_WRAP
#include "wrap_ITKCommonB.cxx"
