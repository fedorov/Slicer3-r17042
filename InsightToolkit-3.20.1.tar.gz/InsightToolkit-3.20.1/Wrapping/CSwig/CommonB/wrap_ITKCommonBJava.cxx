#define ITK_WRAP_PACKAGE "ITKCommonBJava"
#include "wrap_ITKCommonB.cxx"
