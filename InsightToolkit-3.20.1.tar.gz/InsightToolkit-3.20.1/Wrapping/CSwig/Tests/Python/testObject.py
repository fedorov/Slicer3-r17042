from InsightToolkit import *
s = itkObject_New()

