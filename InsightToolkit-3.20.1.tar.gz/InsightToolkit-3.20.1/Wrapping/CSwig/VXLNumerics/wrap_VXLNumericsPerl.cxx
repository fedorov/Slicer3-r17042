#define ITK_WRAP_PACKAGE "VXLNumericsPerl"
#include "wrap_VXLNumerics.cxx"
