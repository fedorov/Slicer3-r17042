#define ITK_WRAP_PACKAGE "VXLNumericsPython"
#include "wrap_VXLNumerics.cxx"
