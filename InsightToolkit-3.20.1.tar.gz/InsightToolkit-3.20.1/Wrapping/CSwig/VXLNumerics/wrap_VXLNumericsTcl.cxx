#define ITK_WRAP_PACKAGE "VXLNumericsTcl"
#include "wrap_VXLNumerics.cxx"
