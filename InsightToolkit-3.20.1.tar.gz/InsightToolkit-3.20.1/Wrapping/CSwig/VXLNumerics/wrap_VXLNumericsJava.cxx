#define ITK_WRAP_PACKAGE "VXLNumericsJava"
#include "wrap_VXLNumerics.cxx"
