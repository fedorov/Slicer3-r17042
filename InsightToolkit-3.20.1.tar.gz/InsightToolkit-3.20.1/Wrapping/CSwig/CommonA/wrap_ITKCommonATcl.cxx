#define ITK_WRAP_PACKAGE "ITKCommonATcl"
#define ITK_TCL_WRAP
#include "wrap_ITKCommonA.cxx"
