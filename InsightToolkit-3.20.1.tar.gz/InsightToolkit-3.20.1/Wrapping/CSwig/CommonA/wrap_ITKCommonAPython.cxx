#define ITK_WRAP_PACKAGE "ITKCommonAPython"
#define ITK_PYTHON_WRAP
#include "wrap_ITKCommonA.cxx"
