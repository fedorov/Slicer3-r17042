#define ITK_WRAP_PACKAGE "ITKCommonAJava"
#include "wrap_ITKCommonA.cxx"
