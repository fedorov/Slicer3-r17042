#define ITK_WRAP_PACKAGE "ITKPatentedTcl"
#include "wrap_ITKPatented.cxx"
