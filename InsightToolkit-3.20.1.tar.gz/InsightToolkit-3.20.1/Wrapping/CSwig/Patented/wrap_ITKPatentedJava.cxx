#define ITK_WRAP_PACKAGE "ITKPatentedJava"
#include "wrap_ITKPatented.cxx"
