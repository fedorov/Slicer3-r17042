#define ITK_WRAP_PACKAGE "ITKPatentedPython"
#include "wrap_ITKPatented.cxx"
