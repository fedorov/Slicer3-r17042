import itkbase

__itk_import_data__ = itkbase.preimport()
from VXLNumericsPython import *
itkbase.postimport(__itk_import_data__)
