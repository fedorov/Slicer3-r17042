#define ITK_WRAP_PACKAGE "ITKNumericsJava"
#include "wrap_ITKNumerics.cxx"
