#define ITK_WRAP_PACKAGE "ITKNumericsTcl"
#include "wrap_ITKNumerics.cxx"
