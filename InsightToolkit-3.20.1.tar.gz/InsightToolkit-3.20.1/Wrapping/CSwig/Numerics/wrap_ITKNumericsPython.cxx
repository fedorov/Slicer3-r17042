#define ITK_WRAP_PACKAGE "ITKNumericsPython"
#include "wrap_ITKNumerics.cxx"
