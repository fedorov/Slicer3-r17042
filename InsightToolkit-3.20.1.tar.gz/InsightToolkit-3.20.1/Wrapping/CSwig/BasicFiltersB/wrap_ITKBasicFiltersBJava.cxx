#define ITK_WRAP_PACKAGE "ITKBasicFiltersBJava"
#include "wrap_ITKBasicFiltersB.cxx"
