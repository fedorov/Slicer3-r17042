#define ITK_WRAP_PACKAGE "ITKBasicFiltersBPython"
#include "wrap_ITKBasicFiltersB.cxx"
