#define ITK_WRAP_PACKAGE "ITKBasicFiltersBTcl"
#include "wrap_ITKBasicFiltersB.cxx"
