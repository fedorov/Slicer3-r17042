#define ITK_WRAP_PACKAGE "ITKIOTcl"
#define ITK_TCL_WRAP
#include "wrap_ITKIO.cxx"
