#define ITK_WRAP_PACKAGE "ITKIOPython"
#include "wrap_ITKIO.cxx"
