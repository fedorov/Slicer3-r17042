#define ITK_WRAP_PACKAGE "ITKIOJava"
#define ITK_JAVA_WRAP
#include "wrap_ITKIO.cxx"
