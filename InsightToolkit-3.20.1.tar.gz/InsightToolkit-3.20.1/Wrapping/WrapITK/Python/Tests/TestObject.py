import itk
itk.auto_progress(2)

s = itk.Object.New()

