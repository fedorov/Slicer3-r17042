void ITKJavaJarDummyLibrary()
{
}
