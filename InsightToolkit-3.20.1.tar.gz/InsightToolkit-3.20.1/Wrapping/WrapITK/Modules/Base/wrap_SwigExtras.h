#ifdef CABLE_CONFIGURATION

namespace _cable_
{
  namespace renames
  {
    typedef std::vector<std::string>::vector StringVector;
    typedef std::list<std::string>::list StringList;
  }
}

#endif
