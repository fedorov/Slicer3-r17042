// This is vcl/vcl_cstdlib.cxx

//:
// \file
// \author fsm

#include "vcl_cstdlib.h"
// A dummy symbol to avoid missing symbol warnings from ranlib
void vcl_cstdlib_dummy_to_avoid_ranlib_warning() {}

// drop your inlines here....
