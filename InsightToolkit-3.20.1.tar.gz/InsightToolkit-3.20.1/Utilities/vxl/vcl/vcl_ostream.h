#ifndef vcl_ostream_h_
#define vcl_ostream_h_
/*
  fsm
*/

#include "vcl_compiler.h"

#if VCL_CXX_HAS_HEADER_OSTREAM
# include "iso/vcl_ostream.h"
#else
# include "vcl_iostream.h" // this should do it.
#endif

#endif // vcl_ostream_h_
