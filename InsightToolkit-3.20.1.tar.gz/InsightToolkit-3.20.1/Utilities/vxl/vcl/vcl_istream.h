#ifndef vcl_istream_h_
#define vcl_istream_h_
/*
  fsm
*/

#include "vcl_compiler.h"

#if VCL_CXX_HAS_HEADER_ISTREAM
# include "iso/vcl_istream.h"
#else
# include "vcl_iostream.h" // this should do it.
#endif

#endif // vcl_istream_h_
