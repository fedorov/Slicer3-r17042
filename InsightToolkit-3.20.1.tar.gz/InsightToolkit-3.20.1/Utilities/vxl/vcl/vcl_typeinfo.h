#ifndef vcl_typeinfo_h_
#define vcl_typeinfo_h_

#include "vcl_compiler.h"

#if VCL_CXX_HAS_HEADER_TYPEINFO
# include "iso/vcl_typeinfo.h"
#else
  *** too bad ***
#endif

#endif // vcl_typeinfo_h_
