#ifndef vcl_win32_vc60_cstdarg_h_
#define vcl_win32_vc60_cstdarg_h_

#include <cstdarg>

#ifdef vcl_generic_cstdarg_STD
  ** error **
#else
# define vcl_generic_cstdarg_STD
#endif

#include "../generic/vcl_cstdarg.h"

#endif // vcl_win32_vc60_cstdarg_h_
