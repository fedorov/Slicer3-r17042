// This is vcl/vcl_stdexcept.h
#ifndef vcl_stdexcept_h_
#define vcl_stdexcept_h_
//:
// \file
// \author fsm

#include "vcl_compiler.h"

#include "iso/vcl_stdexcept.h"

#endif // vcl_stdexcept_h_
