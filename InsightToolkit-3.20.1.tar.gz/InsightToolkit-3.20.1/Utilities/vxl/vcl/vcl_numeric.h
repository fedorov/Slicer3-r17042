#ifndef vcl_numeric_h_
#define vcl_numeric_h_
/*
  fsm
*/

#include "vcl_compiler.h"

#include "iso/vcl_numeric.h"

#endif // vcl_numeric_h_
